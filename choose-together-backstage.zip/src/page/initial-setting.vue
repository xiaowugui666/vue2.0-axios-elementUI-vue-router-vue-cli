<template>
  <div class="">
    <menu-left></menu-left>
    <div>asdasdasd</div>
  </div>
</template>

<script>
import menuLeft from '@/components/menu-left'
export default {
  data () {
    return {
    }
  },
  components: {
    menuLeft
  }
}

</script>
<style scoped>
</style>
