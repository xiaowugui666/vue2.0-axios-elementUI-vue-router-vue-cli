<template>
    <div>customerManagement</div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<style scoped>

</style>
